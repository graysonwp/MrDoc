public class Bar {
  private static void staticMethod() { }
  public void method() { }
  protected Bar() { }
}
