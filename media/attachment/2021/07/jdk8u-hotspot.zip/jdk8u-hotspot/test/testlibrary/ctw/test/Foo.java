public class Foo {
  private static void staticMethod() { }
  public void method() { }
  protected Foo() { }
}
