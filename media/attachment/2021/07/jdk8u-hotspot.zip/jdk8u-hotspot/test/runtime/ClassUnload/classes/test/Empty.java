package test;

public class Empty {
public String toString() { return "nothing"; }
}
