public class T
{
  public static boolean foo(boolean bar)
  {
    return bar;
  }

  public static void printIt()
  {
    System.out.println("Hello");
  }
}
