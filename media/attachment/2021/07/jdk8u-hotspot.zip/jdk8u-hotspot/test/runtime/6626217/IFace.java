// A simple interface, to allow an unknown foreign call from a class
// loaded with LOADER1 to a class loaded with LOADER2.
public interface IFace {
  public many_loader[] gen();
}

