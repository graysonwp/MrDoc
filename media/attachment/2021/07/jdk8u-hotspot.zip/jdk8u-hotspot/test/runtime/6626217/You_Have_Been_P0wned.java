
// I can cast any old thing I want to this type object:
public class You_Have_Been_P0wned {
  // Make a bunch of int-fields so I can peek & poke it
  int _a;
  int _b;
  int _c;
  int _d;

}

