---
sidebar_position: 3
---

> 拥抱开源，创造经典。

## [labuladong 的算法小抄](https://labuladong.gitbook.io/algo)

刷算法全靠套路，认准 labuladong 就够了！

## [LeetCode Cookbook](https://books.halfrost.com/leetcode)

Solutions to LeetCode by Go, 100% test coverage, runtime beats 100%.

## [剑指 Offer 及大厂系列题解](https://offer.hi-dhl.com/#/menu?id=%e7%9b%ae%e5%bd%95)

剑指 offer 及大厂面试题解，每道题目都会用 Java 和 kotlin 去实现，每题都有解题思路、时间复杂度、空间复杂度、源代码。

## [阿秀的校招笔记](https://interviewguide.cn/)

你只管努力，剩下的交给时间就好，我就是活生生的例子！

## [深入浅出 Java 多线程](http://concurrent.redspider.group/RedSpider.html)

这是 RedSpider 社区成员原创与维护的 Java 多线程系列文章。

## [代码随想录](https://programmercarl.com)

认准代码随想录，学习算法不迷路。

## [Go 语言设计与实现](https://draveness.me/golang)

各位读者朋友，很高兴大家通过本博客学习 Go 语言，感谢一路相伴！

