---
sidebar_position: 1
---

 > Although the road is far away, the line will come soon. God rewards hard work, accumulates wealth.

## NAME

CN: Peng Wei | EN: Ricear

## Summary

Peng Wei is a professional developer who focuses on Back-End Development now. He likes to accumulate knowledge and writes his personal thoughts on programming and tech in his personal [blog](https://notebook.ricear.com) beacuse he thinks *Although the road is far away, the line will come soon. God rewards hard work, accumulates wealth.*  He enjoys deep thinking and likes to find out the true theory of every single knowledge. He loves algorithms and advanced mathematics, wining medals in Computer Design Competition and ICM.

Peng Wei also is a photographer and loves to record every single beauty of life with camera, which has received nearly 10k downloads and more than 0.38 million views with 24 photos on [Unsplash](https://unsplash.com/@ricear). He is always willing to try new things, and keeping to learn from them.

Now, he is a M.Eng student of Software Engineering in Behang University.

## Interests

* Back-End Development
* Distributed System
* Big Data

## Education

2020 - 2023 MA.Eng in Software Engineering, [Beihang University](https://buaa.edu.cn), Beijing, China.

2016 - 2018 BBA in Information Management and Information System, Liaoning Technical University, Liaoning, China.

2014 - 2016 Study in Science Class, [Liaoning Technical University](https://www.lntu.edu.cn), Liaoning, China.

## Experience

### Didi

> Department: Online Car-hailing Quality and Efficiency Department
>
> Position: Back End Engineer Intern
>
> Time: 2021.10 - 2022.04

![](https://notebook.ricear.com/media/202204/2022-04-13_1546480.1872999721663492.png)

* Participate in the development of DIY self-test platform. It mainly solves the problems of stateless management of the execution process of the existing platform and the construction of general link-level scenarios around the order flow. Support users to create customized scenario use cases through visual link assembly; realize collaborative sharing across teams through collaborative sharing mode. Mainly responsible for the development of use case management and use case editing modules. Use Python's Django framework as the core of the project architecture; implement data buffering, interface parameter consumption and session sharing based on Redis. Since its launch one month ago, it has accumulated 1,625 cases, and has run a total of 185,146 cases, covering 211 scenarios and involving 441 users in 18 business lines of the group.
  


### Transwarp

> Department: Finance Division
>
> Position: Back End Engineer Intern
>
> Time: 2020.12 - 2021.06

![](https://notebook.ricear.com/media/202107/2021-07-24_102733.png)

- Participated in the development of the CSI monitoring intra-city backup system. The main task is to migrate the data from Teradata to the TDH platform. During the migration process, there are challenges such as large amount of data, parallel increase in storage, and inconsistent data format. Mainly responsible for the development of task scheduling module. Use SpringBoot as the main framework; Druid as the database connection pool; Spring Data JPA as the underlying database interaction framework; Nginx+Keepalived to achieve high availability cluster; multithreading as the core of the scheduling system. After the project was launched, the migration of about 280 tables and 300G data was completed every day.

## Accomplishments

* [The 10th China University Student Computer Design Competition, Second Prize, Aug 2017.](https://notebook.ricear.com/media/202106/2017%E5%B9%B4%EF%BC%88%E7%AC%AC10%E5%B1%8A%EF%BC%89%E4%B8%AD%E5%9B%BD%E5%A4%A7%E5%AD%A6%E7%94%9F%E8%AE%A1%E7%AE%97%E6%9C%BA%E8%AE%BE%E8%AE%A1%E5%A4%A7%E8%B5%9B%E5%9B%BD%E5%AE%B6%E4%BA%8C%E7%AD%89%E5%A5%96_1623555245.jpg)
* [2017 Liaoning General Colleges and Universities Undergraduate Computer Design Competition, Second Prize, May 2017.](https://notebook.ricear.com/media/202106/2017%E5%B9%B4%E8%BE%BD%E5%AE%81%E7%9C%81%E5%A4%A7%E5%AD%A6%E7%94%9F%E8%AE%A1%E7%AE%97%E6%9C%BA%E8%AE%BE%E8%AE%A1%E5%A4%A7%E8%B5%9B%E7%9C%81%E4%BA%8C%E7%AD%89%E5%A5%96_1623555255.jpg)
* [2017 Interdisciplinary Contest in Modeling, Meritorious Winner, Jan 2017.](https://notebook.ricear.com/media/202106/2017%E5%B9%B4%E7%BE%8E%E5%9B%BD%E5%A4%A7%E5%AD%A6%E7%94%9F%E6%95%B0%E5%AD%A6%E5%BB%BA%E6%A8%A1%E7%AB%9E%E8%B5%9BMathor%E5%A5%96%EF%BC%88%E4%B8%80%E7%AD%89%E5%A5%96%EF%BC%89%E8%AF%81%E4%B9%A6_1623555272.jpg)
* [2014-2015 National Inspirational Scholarship Certificate, Dec 2015.](https://notebook.ricear.com/media/202106/2014-2015%E5%B9%B4%E5%9B%BD%E5%AE%B6%E5%8A%B1%E5%BF%97%E5%A5%96%E5%AD%A6%E9%87%91%E8%AF%81%E4%B9%A6_1623555207.jpg)
* [Certificate of Merit in Academic Year 2014-2015, Ranking: Top-3, Jun 2015.](https://notebook.ricear.com/media/202106/2014-2015%E5%AD%A6%E5%B9%B4%E5%AD%A6%E5%B9%B4%E6%88%90%E7%BB%A9%E4%BC%98%E5%BC%82%E8%AF%81%E4%B9%A6_1623555218.jpg)
* [2015 National English Competition for College Students, Second Price for Band C, May 2015.](https://notebook.ricear.com/media/202106/2015%E5%B9%B4%E5%85%A8%E5%9B%BD%E5%A4%A7%E5%AD%A6%E7%94%9F%E8%8B%B1%E8%AF%AD%E7%AB%9E%E8%B5%9B%E5%9B%BD%E5%AE%B6%E4%BA%8C%E7%AD%89%E5%A5%96_1623555232.jpg)

## Contact

Github: [Ricear](https://github.com/ricear)

Email: [i@ricear.com](mailto:i@ricear.com)
