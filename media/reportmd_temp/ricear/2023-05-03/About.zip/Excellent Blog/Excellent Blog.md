---
sidebar_position: 2
---

> 向最优秀的人学习，使自己变得越来越优秀。

## [Vivek Patel](https://vivek9patel.github.io)

Ex-SWE Intern HackerRank ⚡️ Building cool things on the web 🚀 Computer Science 👨🏻‍💻

## [Xiaohan Zou](https://zxh.io)

A dragon lost in human world.

## [Jark\'s Blog](http://wuchong.me)

* CN: 伍 翀（WuChong） | EN: Jark | 花名: 云邪
* Apache Flink Committer。

## [Blanker\'s Blog](https://blog.isaaclin.cn)

万物生长，各自高贵。

## [张戈博客](https://zhang.ge)

把最实用的经验，分享给最需要的读者，希望每一位来访的朋友都能有所收获！

## [zhisheng 的博客](http://www.54tianzhisheng.cn)

坑要一个个填，路要一步步走！

## [Dunwu](https://dunwu.github.io/blog)

大道至简，知易行难。

## [尾尾部落](https://weiweiblog.cn)

永远年轻，永远热泪盈眶！

## [曹世宏的博客](https://cshihong.github.io)

你的责任就是你的方向，你的经历就是你的资本，你的性格就是你的命运。

## [小土刀 2.0](https://wdxtub.com)

上士闻道，勤而行之。

## [Images\'Blog](https://imageslr.com)

Hungry. Foolish. Simple. Naive.

## [Halfrost\'s Field | 冰霜之地](https://halfrost.com)

Explore in every moment of the hard thinking.

## [Startup Next Door](https://startupnextdoor.com)

A long journey from startups to software engineering.

## [codedump 的网络日志](https://www.codedump.info)

发表是最好的记忆。

## [Quguang\'s Blog](https://quguang.wang)

当你的才华还撑不起你的野心的时候，你就应该静下心来学习；当你的能力还驾驭不了你的目标时，就应该沉下心来，历练；梦想，不是浮躁，而是沉淀和积累，只有拼出来的美丽，没有等出来的辉煌，机会永远是留给最渴望的那个人。

## [王下邀月熊](https://ng-tech.icu)

Just Coder, Travel in the Galaxy.

## [酷 壳 – CoolShell](https://coolshell.cn)

享受编程和技术所带来的快乐 – Coding Your Ambition.

## [Yasin Shaw](https://yasinshaw.com)

不问天涯，诗酒趁年华。

## [huangz](http://huangz.me)

IT 技术图书作者和译者。

## [笑话人生](https://www.cylong.com)

年华易逝，懂得珍惜。

## [Overseas Rabbit | 海外兔](https://osjobs.net)

海内外工作的经验交流，信息分享。

## [Tianshi Li](https://tianshili.me)

Ph.D. student in HCI.

## [Hongda Jiang](https://jianghd1996.github.io)

PhD student of computer graphics.

## [Mingrui (Ray) Zhang](https://drustz.com)

PhD @ACE Lab, UW Seattle.

## [JACKIE YANG](https://jackieyang.me)

PhD student at Stanford University.

## [Kevinello](https://kevinello.ltd)

Come and make a MOVE.

## [Java 全栈知识体系](https://www.pdai.tech)

你的时间花在哪里，你的收获就在哪里。技术只是技术，生活中的一小部分，仅此而已。

## [Carol&#39;s blog](https://dyfloveslife.github.io)

Dare to dream, dare to do!

## [陈树义的博客](https://shuyi.tech)

分享我的所思所想。

## [Javadoop](https://www.javadoop.com)

我是来自魔都的程序员，在互联网摸爬滚打了很多年。

## [Leo 的博客](https://leehao.me)

记录开发的点滴。

## [随心](https://dolyw.com)

愿你出走半生，归来仍是少年。

## [ZhouJ000 Blog](https://zhouj000.github.io)

精彩不亮丽，起落是无常。

## [JavaGuide](https://snailclimb.gitee.io)

Talk is cheap,show me the code!

## [lucifer | Full Stack Dev](https://lucifer.ren)

Hello, I'm lucifer!

## [draveness](https://draveness.me)

面向信仰编程。

## [负雪明烛](https://fuxuemingzhu.cn)

苍山负雪，明烛天南。
