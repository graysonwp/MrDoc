---
sidebar_position: 4
---

> 贡献开源，登高望远。

## Resume

### [vivek9patel.github.io](https://github.com/vivek9patel/vivek9patel.github.io)

Personal portfolio website of theme Ubuntu 20.04, made using NEXT.js & tailwind CSS.

### [playground-macos](https://github.com/Renovamen/playground-macos)

My portfolio website simulating macOS's GUI, developed with React and UnoCSS.
