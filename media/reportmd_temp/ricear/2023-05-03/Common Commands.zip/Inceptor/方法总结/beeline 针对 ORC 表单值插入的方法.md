---
sidebar_position: 1
---

```sql

insert into database.table select "transwarp", 1 from system.dual;
```

