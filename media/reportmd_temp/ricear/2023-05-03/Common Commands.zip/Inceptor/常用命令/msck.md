---
sidebar_position: 3
---

```sql

-- 当一个分区表先在 hdfs 上创建目录，上后再上传文件到 hdfs 指定分区目录时，hive 不回识别该分区目录，需要使用 msck 来让 hive 创建相应分区，这样便可以从 hive 中查询到相应分区中的数据
-- msck 只能用于外表，且只能在分区不存在时创建分区，而不能删除分区
msck repair table employees;
```

