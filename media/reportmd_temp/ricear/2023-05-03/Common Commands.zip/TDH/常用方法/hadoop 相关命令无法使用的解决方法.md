---
sidebar_position: 1
---

找到 TDH-Client 所在的目录(假如是~/TDH-Client)，则需要使用以下命令：


```shell
source ~/TDH-Client/init.sh
```

执行上面操作后，就可以使用 hadoop 相关命令了。


