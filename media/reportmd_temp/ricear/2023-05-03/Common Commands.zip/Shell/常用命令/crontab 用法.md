---
sidebar_position: 4
---

```shell
# 查看 crontab 运行日志
cat /var/log/cron

# 每天 02:00 执行任务
0 2 * * * /bin/sh backup.sh
# 每天 5:00 和 17:00 执行任务
0 5,17 * * * /scripts/script.sh
# 每分钟执行一次任务
* * * * *  /scripts/script.sh
# 每周日 17:00 执行任务
0 17 * * sun  /scripts/script.sh
# 每 10min 执行一次任务
*/10 * * * * /scripts/monitor.sh
# 在特定的某几个月执行任务(在一月、五月、八月每天每分钟执行任务)
* * * jan,may,aug * /script/script.sh
# 在特定的某几天执行任务(在每周五、周日的 17 点执行任务)
0 17 * * sun,fri /script/scripy.sh
# 每四个小时执行一个任务
0 */4 * * * /scripts/script.sh
# 每周一、周日 4:00 和 17:00 执行任务
0 4,17 * * sun,mon /scripts/script.sh
# 每个 30 秒执行一次任务
* * * * * sleep 30; /scripts/script.sh
# 多个任务在一条命令中配置
* * * * * /scripts/script.sh; /scripts/scrit2.sh
# 每年执行一次任务(@yearly 类似于“0 0 1 1 *”。它会在每年的第一分钟内执行，通常我们可以用这个发送新年的问候。)
@yearly /scripts/script.sh
# 系统重启时执行
@reboot /scripts/script.sh
# 将 Cron 结果重定向的特定的账户(默认情况下，cron 只会将结果详情发送给 cron 被制定的用户。如果需要发送给其他用户，可以通过如下的方式)
MAIL=bob
0 2 * * * /script/backup.sh
# 将所有的 cron 命令备份到文本文件当中
# 1、备份 cron 到文件中
crontab -l > cron-backup.txt
# 2、移除当前的 cron
crontab -r
# 3、从 text file 中恢复
crontab cron-backup.txt
```


