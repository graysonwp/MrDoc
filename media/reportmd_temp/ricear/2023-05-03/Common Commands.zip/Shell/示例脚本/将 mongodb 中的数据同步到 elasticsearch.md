---
sidebar_position: 4
---

```shell
#!/bin/bash

# 将 mongodb 中的数据同步到 elasticsearch
# 日期格式
DATE_FORMAT="+%Y%m%d"
# 起始日期
if [ ! ${1} ]; then
	START_DAY=`date -d "-1day" ${DATE_FORMAT}`
else
	START_DAY=`date -d "-1day ${1}" ${DATE_FORMAT}`
fi
# 截止日期
if [ ! ${2} ]; then
	END_DAY=${START_DAY}
else
	END_DAY=`date -d "-1day ${2}" ${DATE_FORMAT}`
fi
echo ${START_DAY}
echo ${END_DAY}
# python 脚本路径
PYTHON_SCRIPT_PATH="/usr/local/projects/PocketFilm/Spider/PocketLifeSpider/PocketLifeSpider"

START_DAY_TMP=${START_DAY}
END_DAY_TMP=${END_DAY}
while (( "${START_DAY_TMP}" <= "${END_DAY_TMP}" )); do
 cur_day=`date -d ${START_DAY_TMP} ${DATE_FORMAT}`
 echo "Current date is ${cur_day}:"
 echo "Run mongo-to-es.py"
 /usr/local/python3/bin/python3 ${PYTHON_SCRIPT_PATH}/mongo-to-es.py ${cur_day}
 START_DAY_TMP=`date -d "+1day ${START_DAY_TMP}" ${DATE_FORMAT}`
done
```


