---
sidebar_position: 1
---

```bash
beeline -u "jdbc:hive2://localhost:10000"  -n lenmom -p  123456
```


