---
sidebar_position: 2
---

## 1 安装《QQ空间导出助手》插件

【附件】[QQ空间导出助手-1.1.3_0.zip](https://notebook.ricear.com/media/attachment/2021/06/QQ%E7%A9%BA%E9%97%B4%E5%AF%BC%E5%87%BA%E5%8A%A9%E6%89%8B-1.1.3_0.zip)

将上述插件下载并解压后，拖到谷歌浏览器里面进行安装即可。

## 2 在浏览器设置中选择要保存的位置，关闭“下载前询问每个文件的保存位置”功能

![](https://notebook.ricear.com/media/202106/2021-06-23_114708.png)

## 3 登录QQ空间

![](https://notebook.ricear.com/media/202106/2021-06-23_114423.png)

## 3 点击右上角的《QQ空间导出助手》图标，选择需要导出的信息，然后点击“开始备份”

![](https://notebook.ricear.com/media/202106/2021-06-23_114827.png)

![](https://notebook.ricear.com/media/202106/2021-06-23_114923.png)

![](https://notebook.ricear.com/media/202106/2021-06-23_120627.png)
