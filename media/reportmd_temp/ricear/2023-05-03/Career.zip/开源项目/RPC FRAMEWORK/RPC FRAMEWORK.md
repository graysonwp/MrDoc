---
sidebar_position: 1
---

 ## 介绍

一个简单的 [RPC](https://notebook.ricear.com/project-46/doc-836) 框架。主要包括 **注册中心**、**远程调用**、**容错机制**、**负载均衡** 四个核心模块。采用 ZooKeeper 作为注册中心；设计了一套客户端与服务端通信协议；支持多种容错机制和负载均衡策略。初步实现了一个高可用的 RPC 框架。

## 设计

### 架构

![image-20220808145944105](https://notebook.ricear.com/media/202208/2022-08-08_145957_6834070.0790627088880893.png)

1. Provider 启动时会向 **注册中心** 把自己的元数据 **注册** 上去（比如服务 IP 和端口等）。
2. Consumer 在启动时从注册中心 **订阅**（第一次订阅会拉取全量数据）服务提供方的元数据，注册中心中发生 **数据变更** 后会推送给订阅的 Consumer。
3. 在获取服务元数据后，Consumer 可以发起 **RPC 调用**，在 RPC 调用前后会向监控中心上报统计信息（比如并发数和调用的接口）。

### 原理

#### 注册中心

##### 概述

在整个框架中，注册中心是核心组件之一，通过注册中心实现了各服务之间的注册与发现，是各个节点之间的纽带，主要作用如下：

- **动态加入**：一个服务提供者通过注册中心可以动态地把自己暴露给其他消费者，无须消费者逐个去更新配置文件。
- **动态发现**：一个消费者可以动态地感知新的配置、路由规则和新的服务提供者，无需重启服务使之生效。
- **动态调整**：注册中心支持参数的动态调整，新参数自动更新到所有相关服务节点。
- **统一配置**：避免了本地配置导致每个服务的配置不一致的问题。

##### 工作流程

注册中心的总体流程如下图所示

![image-20220808154116561](https://notebook.ricear.com/media/202208/2022-08-08_154128_0685660.8118587437036361.png)

- **服务提供者** 启动时，会向注册中心 **写入自己的元数据信息**，同时会 **订阅配置元数据信息**。
- **消费者** 启动时，也会向注册中心 **写入自己的元数据信息**，并 **订阅服务提供者**、**路由** 和 **配置元数据信息**。
- **服务治理中心** 启动时，会同时 **订阅所有消费者**、**服务提供者**、**路由** 和 **配置元数据信息**。
- 当有 **服务提供者离开** 或有 **新的服务提供者加入** 时，注册中心 **服务提供者目录会发生变化**，变化信息会 **动态通知给消费者**、**服务治理中心**。
- 当 **消费方发起服务调用** 时，会 **异步将调用**、**统计信息等上报给监控中心**。

##### 数据结构

> :thinking: 为什么采用 ZooKeeper 作为注册中心。？
>
> - ZooKeeper 的 **数据模型很简单**，由一系列被称为 ZNode 的数据节点组成，是一个 **树形的目录服务**，**便于注册中心注册和查找服务地址**。
> - **将全量数据存储在内存中**（性能高），**支持集群**（高可用）。
> - **支持 [事件监听](https://notebook.ricear.com/project-50/doc-864)**，**方便变更推送**。

> :thinking: 为什么不选用 Redis 作为注册中心？
>
> - Redis 做注册中心 **服务器事件必须同步**，否则可能出现 **时间不对被强制过期**（删除 key）。
> - ZooKeeper 支持监听，Redis 不支持，因此 **需要客户端启动多个线程进行订阅监听**，**对服务器有一定压力**。

1. ZooKeeper 是 **树形结构** 的注册中心，每个节点的类型分为 **持久节点**、**持久顺序节点**、**临时节点** 和 **临时顺序节点**。

   > **持久节点**：服务注册后保证节点不会丢失，注册中心重启也会存在。
   >
   > **持久顺序节点**：在持久节点特性的基础上增加了节点先后顺序的能力。
   >
   > **临时节点**：服务注册后连接丢失或 session 超时，注册的节点会自动被移除。
   >
   > **临时顺序节点**：在临时节点特性的基础上增加了节点先后顺序的能力。
   
   > 框架在使用 ZooKeeper 作为注册中心时，只会创建 **持久节点** 和 **临时节点** 两种，对创建的顺序并没有要求。

2. ZooKeeper 的树形结构如下图所示：

   ![image-20220808160448995](https://notebook.ricear.com/media/202208/2022-08-08_160500_3371930.287134370897404.png)

   1. 树的根节点是 **注册中心分组**，下面有多个 **服务接口**，分组值来自用户配置 `<dubbo:registry>` 中的 `group` 属性，默认是 `/dubbo`。

   2. 服务接口下包含 4 类子目录（**持久节点**）：

      1. providers：**服务提供者目录**，下面包含的接口有多个服务者 URL 元数据信息。
      2. consumers：**服务消费者目录**，下面包含的接口有多个消费者 URL 元数据信息。
      3. routers：**路由配置目录**，下面包含多个用于消费者路由策略 URL 元数据信息。
      4. configurators：**动态配置目录**，下面包含多个用于服务者动态配置 URL 元数据信息。

   3. 在框架启动时，会根据用户配置的服务，在注册中心中创建 4 个目录，在 providers 和 consumers 目录中分别存储服务提供方、消费方元数据信息，主要包括 IP、端口、权重和应用名等。

   4. 在框架进行服务调用时，用户可以通过服务治理平台下发路由配置，如果要 **在运行时改变服务参数**，则用户可以通过服务治理平台 **下发动态配置**，服务器端会通过 **订阅机制** 收到属性变更，并重新 **更新已经暴露的服务**。

   5. 服务元数据中的所有 **参数** 都是以 **键值对** 形式存储的。

      ![image-20220808171455086](https://notebook.ricear.com/media/202208/2022-08-08_171507_8178420.31261859916773826.png)

      > 例如 `dubbo://192.168.0.1.20880/com.alibaba.demo.Service?category=provider&name=demo-provider&...` 中包含两个键值对，第一个 `key` 为 `category`，`key` 的关联值为 provider。

##### 订阅/发布

- 订阅/发布是整个注册中心的核心功能之一。

  > 在传统应用系统中，我们通常会把配置信息写入一个配置文件，当配置需要变更时会修改配置文件，再通过 **手动触发内存中的配置** 重新加载，如重新服务等。当集群规模较小的场景下，这种方式也能方便地进行运维，当服务节点数量不断上升的时候，这种管理方式的弊端就会凸显现出来。

- 如果我们使用了注册中心，那么上述的问题就会迎刃而解。

  > 当一个已有服务提供者节点 **下线**，或者一个新的服务提供者节点 **加入** 微服务环境时，**订阅对应接口** 的消费者和服务治理中心都能及时收到注册中心的通知，并 **更新本地的配置信息**。如此一来，后续的服务调用就能 **避免调用已经下线的节点**，或者能 **调用到新的节点**，整个过程都是自动完成的，不需要人工参与。

###### 发布

1. **服务提供者** 和 **消费者** 都需要把自己注册到注册中心。

   > - 服务提供者的注册是为了 **让消费者感知服务的存在**，从而发起远程调用，也 **让服务治理中心感知有新的服务提供者上线**。
   > - 消费者的发布是为了 **让服务治理中心可以发现自己**。

2. ZooKeeper 发布代码非常简单，只是调用了 ZooKeeper 的客户端在注册中心上创建一个目录。

   ~~~java
   zkClient.create(toUrlPath(url), url.getParameter(Constants.DYNAMIC_KEY, true));
   ~~~

   取消发布也很简单，只是把 ZooKeeper 注册中心上对应的路径删除。

   ~~~java
   zkClient.delete(toUrlPath(url));
   ~~~

###### 订阅

1. 订阅通常有 pull 和 push 两种方式。

   > - 一种是客户端 **定时轮询注册中心拉取配置**。
   > - 另一种是注册中心 **主动推送数据给客户端**。

2. ZooKeeper 注册中心采取的是『**事件通知**』+『**客户端拉取**』的方式。

   > - 客户端在 **第一次** 连接上注册中心时，会获取 **对应目录下全量的数据**，并 **在订阅的节点注册一个 watcher**，**客户端与注册中心保持 [TCP 长连接](https://notebook.ricear.com/project-26/doc-801/#2-%E9%95%BF%E8%BF%9E%E6%8E%A5)**。
   > - 后续每个节点有任何数据变化的时候，注册中心会根据 watcher 的回调 **主动通知客户端**（事件通知），客户端接到通知后，会 **把对应节点下的全量数据都拉取过来**（客户端拉取）。

3. ZooKeeper 的每个节点都有一个版本号，当某个节点的数据发生变化（即 **事务操作**）时，该节点对应的版本号就会发生变化，并 **触发 watcher 事件**，**推送数据给订阅方**，版本号强调的是变更次数，即使该节点的值没有变化，只要有更新操作，依然会使版本号变化。

   > :thinking: 什么操作会被认为是事务操作？
   >
   > - **客户端** 任何 **新增**、**删除**、**修改**、**会话创建** 和 **失效** 操作，都会被认为是事务操作，会由 ZooKeeper 集群中的 leader 执行，即使客户端连接的是非 leader 节点，请求也会被转发给 leader 执行，以此来保证所有 **事务操作的全局时序性**。
   > - 由于每个节点都有一个版本号，因此可以通过 [CAS](https://notebook.ricear.com/project-34/doc-529) 操作比较版本号来保证该节点 **数据操作的原子性**。

4. **全量订阅服务**：

   1. **客户端第一次连上注册中心**，订阅时会获取 **全量的数据**，后续则通过 **监听器事件进行更新**。
   2. **服务治理中心会处理所有 service 层的订阅**，service 被设置成特殊值 *，此外，服务治理中心除了订阅 **当前节点**，还会订阅 **这个节点下的所有子节点**。

   ~~~java
   if (Constants.ANY_VALUE.equals(url.getServiceInterface())) {  // 订阅所有数据
       String root = toRootPath();
       ConcurrentMap<NotifyListener, ChildListener> listeners = zkListeners.get(url);
       if (listeners == null) {  // listeners 为空说明缓存中没有，这里把 listeners 放入缓存
           zkListeners.putIfAbsent(url, new ConcurrentHashMap<NotifyListener, ChildListener>());
           listeners = zkListeners.get(url);
       }
       ChildListener zkListener = listeners.get(listener);
       if (zkListener == null) {
           listeners.putIfAbsent(listener, new ChildListener() {  // zkListener 为空，说明是第一次，新建一个 listener
               @Override
               public void childChanged(String parentPath, List<String> currentChilds) {  // 这时内部类的方法，不会立即执行，只会在触发变更通知时执行
                   for (String child : currentChilds) {  // 如果子节点有变化则会接到通知，遍历所有的子节点
                       child = URL.decode(child);
                       if (!anyServices.contains(child)) {  // 如果存在子节点还未被订阅，说明是新的节点，则订阅
                           anyServices.add(child);
                           subscribe(url.setPath(child).addParameters(Constants.INTERFACE_KEY, child,
                                   Constants.CHECK_KEY, String.valueOf(false)), listener);
                       }
                   }
               }
           });
           zkListener = listeners.get(listener);
       }
       zkClient.create(root, false);  // 创建持久节点，接下来订阅持久节点的直接子节点
       List<String> services = zkClient.addChildListener(root, zkListener);
       if (services != null && !services.isEmpty()) {
           for (String service : services) {  // 然后遍历所有子节点进行订阅
               service = URL.decode(service);
               anyServices.add(service);  // 增加当前节点的订阅，并且会返回该节点下所有子节点列表
               subscribe(url.setPath(service).addParameters(Constants.INTERFACE_KEY, service,
                       Constants.CHECK_KEY, String.valueOf(false)), listener);
           }
       }
   }
   ~~~

   > :information_desk_person: 此处主要支持服务治理平台，平台在启动时会订阅全量接口，他会感知每个服务的状态。

5. **类别订阅服务**：

   1. 首先根据 URL 的类别得到一组需要订阅的路径，如果类别时 *，则会订阅四种类型的路径（providers、routers、consumers、configurators），否则只订阅 providers 路径。

   ~~~java
   List<URL> urls = new ArrayList<URL>();
   for (String path : toCategoriesPath(url)) {  // 根据 url 的类别，获取一组要订阅的路径
       ConcurrentMap<NotifyListener, ChildListener> listeners = zkListeners.get(url);
       if (listeners == null) {  // 如果 listeners 为空，则创建缓存
           zkListeners.putIfAbsent(url, new ConcurrentHashMap<NotifyListener, ChildListener>());
           listeners = zkListeners.get(url);
       }
       ChildListener zkListener = listeners.get(listener);
       if (zkListener == null) {  // 如果 zkListener 缓存为空，则创建缓存
           listeners.putIfAbsent(listener, new ChildListener() {
               @Override
               public void childChanged(String parentPath, List<String> currentChilds) {
                   ZookeeperRegistry.this.notify(url, listener, toUrlsWithEmpty(url, parentPath, currentChilds));
               }
           });
           zkListener = listeners.get(listener);
       }
       zkClient.create(path, false);
       List<String> children = zkClient.addChildListener(path, zkListener);  // 订阅，返回该节点下的子路径并缓存
       if (children != null) {
           urls.addAll(toUrlsWithEmpty(url, path, children));
       }
   }
   notify(url, listener, urls);  // 回调 NotifyListener，更新本地缓存信息
   ~~~

   > :information_desk_person: 此处会根据 URL 中的 category 属性值获取具体的类别（providers、routers、consumers、configurators），然后拉取直接子节点的数据进行通知（`notify`）：
   >
   > - 如果是 **providers** 类别的数据，则订阅方会更新本地 Directory 管理的 Invoker **服务列表**。
   > - 如果是 **routers** 分类，则订阅方会更新 **本地路由规则列表**。
   > - 如果是 **configurators** 类别，则订阅方会更新或覆盖 **本地动态参数列表**。

##### 缓存机制

1. 缓存的存在就是用空间换取时间内，如果每次远程调用都要先从注册中心获取以此可调用的服务列表，则会让注册中心承受巨大的 **流量压力**，另外，每次额外的网络请求也会让整个系统的 **性能下降**。

2. 因此，我们框架的注册中心实现了通用的缓存机制。

   > :information_desk_person: **消费者** 或 **服务治理中心**获取注册信息后会做 **本地缓存**：
   >
   > - **内存** 中会有一份，保存在 **Properties** 对象里。
   > - **磁盘** 上也会持久化一份文件，通过 **file** 对象引用。
   >
   > ~~~java
   > private final Properties properties = new Properties();
   > private File file;  // 磁盘文件服务缓存对象
   > private final ConcurrentMap<URL, Map<String, List<URL>>> notified = new ConcurrentHashMap<URL, Map<String, List<URL>>>();  // 内存中的服务缓存对象
   > ~~~
   >
   > 内存中的缓存 `notified` 是 `ConcurrentHashMap` 里面又嵌套了一个 `Map`：
   >
   > - 外层 `Map` 的 `key` 是消费者的 URL。
   > - 内层 `Map` 的 `key` 是分类，包含 providers、routers、consumers、configurators 四种，`value` 则是对应的 服务列表，对于没有服务提供者提供服务的 URL，他会以特殊的 `empty://` 前缀开头。

3. **缓存的加载**：

   1. 在 **服务初始化** 的时候，`AbstractRegistry` 构造函数里会从 **本地磁盘文件** 中把持久化的注册数据读到 Properties 对象里，并 **加载到内存缓存** 中。

      ~~~java
      private void loadProperties() {
          if (file != null && file.exists()) {
              InputStream in = null;
              try {
                  in = new FileInputStream(file);  // 读取磁盘上的文件
                  properties.load(in);
                  if (logger.isInfoEnabled()) {
                      logger.info("Load registry store file " + file + ", data: " + properties);
                  }
              } catch (Throwable e) {
                  logger.warn("Failed to load registry store file " + file, e);
              } finally {
                  if (in != null) {
                      try {
                          in.close();
                      } catch (IOException e) {
                          logger.warn(e.getMessage(), e);
                      }
                  }
              }
          }
      }
      ~~~

   2. Properties 保存了所有 **服务提供者的 URL**，使用 `URL#serviceKey()` 作为 `key`，**提供者列表**、**路由规则列表**、**配置规则列表** 等作为 `value`，由于 `value` 是列表，当存在多个的时候使用空格隔开。

      > :information_desk_person: 还有一个特殊的 `key`，即 `registies`，保存所有的 **注册中心的地址**。

   3. 如果应用在启动过程中，注册中心无法连接或宕机，则框架会自动通过本地缓存加载 Invokers。

4. **缓存的保存与更新**：

   1. 缓存的保存有 **同步** 和 **异步** 两种方式，异步会使用 [线程池](https://notebook.ricear.com/project-34/doc-818) 异步保存，如果线程在执行过程中出现异常，则会再次调用线程池不断重试。

      ~~~java
      if (syncSaveFile) {
          doSaveProperties(version);  // 同步保存
      } else {
          registryCacheExecutor.execute(new SaveProperties(version));  // 异步保存，放入线程池，会传入一个 AtomicLong 的版本号，保证数据是最新的
      }
      ~~~

   2. `AbstractRegistry#notify` 方法中封装了更新内存缓存和更新文件缓存的逻辑，当客户端 **第一次订阅获取全量数据**，或者后续 **由于订阅得到新数据** 时，都会调用该方法进行保存。

##### 重试机制

1. 我们定义了一个抽象类 `FailbackRegistry`，该抽象类中定义了一个 [ScheduledExecutorService](https://notebook.ricear.com/project-34/doc-818/#2-1-4-2-%E6%9E%84%E9%80%A0%E5%87%BD%E6%95%B0)，每经过固定间隔（默认为 5 秒）调用 `FailbackRegistry#retry()` 方法。

2. `FailbackRegistry` 抽象类中主要有五个比较重要的集合：

   | 集合名称                                                     | 集合介绍                 |
   | ------------------------------------------------------------ | ------------------------ |
   | `Set<URL> failedRegistered`                                  | 发起注册失败的 URL 集合  |
   | `Set<URL> failedUnregistered`                                | 取消注册失败的 URL 集合  |
   | `ConcurrentMap<URL, Set<NotifyListener>> failedSubscribed`   | 发起订阅失败的监听器集合 |
   | `ConcurrentMap<URL, Set<NotifyListener>> failedUnsubscribed` | 取消订阅失败的监听器集合 |
   | `ConcurrentMap<URL, Map<NotifyListener, List<URL>>> failedNotified` | 通知失败的 URL 集合      |

3. 在定时器 ⏲ 中调用 `retry` 方法的时候，会把上面的五个集合 **分别遍历和重试**，**重试成功则从集合中移除**。

   > :thinking: FailbackRegistry 实现了 `subscribe`、`unsubscribe` 等通用方法，里面调用了 **未实现的模板方法**，会 **由子类实现**，通用方法会调用这些模板方法，如果 **捕获到异常**，则会 **把 URL 添加到对应的重试集合中**，以供定时器去重试。

#### 远程调用

##### 调用流程

![image-20220809171515808](https://notebook.ricear.com/media/202208/2022-08-09_171528_1207560.7780259238168006.png)

1. 首先在 **客户端启动** 时会 **从注册中心拉取和订阅对应的服务列表**，然后把拉取的服务列表聚合成一个 **Invoker**，每次 RPC 调用前会通过 `Directory#list` **获取 providers 地址**（已经生成好的 Invoker 列表），以便给后续 **路由** 和 **负载均衡** 使用。

   > :information_desk_person: 在框架内部另外一个实现 Directory 接口是 RegistryDirectory 类，他和接口名是一对一的关系（每一个接口都有一个 RegistryDirectory 实例），主要负责**拉取和订阅服务提供者**、**动态配置** 和 **路由项**。

2. 在发起服务调用时，所有 **路由和负载均衡都是在客户端实现的**。

   > - 客户端服务调用首先会触发 **路由** 操作，然后 **将路由结果得到的服务列表作为负载均衡参数**，经过负载均衡后会选出一台机器进行 **RPC 调用**，这 3 个步骤依次对应于上图中的 ②、③ 和 ④。

3. 客户端经过路由和负载均衡后，会将请求交给 [线程池](https://notebook.ricear.com/project-34/doc-818) 处理，框架中的线程池主要有两种：

   1. **I/O 线程池** ：比如 [Netty](https://notebook.ricear.com/project-49)，主要处理 **读写**、**序列化** 和 **反序列化** 等逻辑。
   2. **业务线程池**：主要承载 **业务方法调用**。

##### 传输协议

```txt
*   0     1     2     3     4        5     6     7     8         9          10      11     12  13  14   15 16
 *   +-----+-----+-----+-----+--------+----+----+----+------+-----------+-------+----- --+-----+-----+-------+
 *   |   magic   code        |version | full length         | messageType| codec|compress|    RequestId       |
 *   +-----------------------+--------+---------------------+-----------+-----------+-----------+------------+
 *   |                                                                                                       |
 *   |                                         body                                                          |
 *   |                                                                                                       |
 *   |                                        ... ...                                                        |
 *   +-------------------------------------------------------------------------------------------------------+
 * 4B  magic code（魔法数）   1B version（版本）   4B full length（消息长度）    1B messageType（消息类型）
 * 1B compress（压缩类型） 1B codec（序列化类型）    4B  requestId（请求的 Id）
```

1. **魔法数**：
   1. 通常来说是**4 字节**。
   2. 主要是为了**筛选来到服务端的数据包**，有了这个魔法数之后，**服务端首先取出前面 4 个字节进行比对**，**能够在第一时间识别出这个数据包并非是遵循自己协议的**，**也就是无效数据包**，**为了安全考虑可以直接关闭连接以节省资源**。
2. **版本**：
   1. 通常来说是**1 字节**。
   2. 主要用来**标识服务的版本**，**为后续不兼容升级提供可能**，比如服务接口增加方法，或服务模型增加字段，**需通过变更版本号升级**。
3. **消息长度**：
   1. **运行时计算出来**。
4. **消息类型**：
   1. 通常来说是**1 字节**。
   2. 主要用来**标识消息是心跳消息还是正常发送的消息**。
5. **压缩类型**：
   1. 通常来说是**1 字节**。
   2. 目前**采用的是 GZIP 压缩**。
6. **序列化类型**：
   1. 通常来说是**1 字节**。
   2. 目前**支持 Kyro 和 Protostuff 两种序列化方式**。
7. **请求 ID**：
   1. 通常来说是**4 字节**。

##### 编解码器

1. **编码器**：
   1. 主要**负责处理出站消息**，**将消息格式转换字节数组然后写入到字节数据的容器 ByteBuf 中**，`body`**部分需要经过序列化对象**、**压缩字节等步骤**。
2. **解码器**：
   1. 主要**负责处理入站消息**，**将 ByteBuf 消息格式的对象转换为我们需要的业务对象**，`body`**部分需要经过解压缩**、**反序列化等步骤**。

#### 容错机制

1. 容错机制能增强整个应用的 **鲁棒性**，容错过程对上层用户是完全透明的，但用户也可以通过不同的配置项来选择不同的容错机制，每种容错机制又有自己个性化的配置项。
2. 整个框架现有 **Failover**、**Failfast**、**Failsafe**、**Failback**、**Forking**、**Broadcast**等容错机制，下面，我们会对这些容错机制及其原理进行详细的阐述。

##### Failover 策略

> - 当出现 **失败** 时，会 **重试其他服务器**，用户可以通过 `retries = 2` 设置重试次数，这是我们框架的 **默认容错机制**。
> - 该机制通常使用在 **读操作** 或 **幂等的写操作** 上，但重试会导致 **接口的延迟增大**，在下游机器负载已经达到极限时，重试容易 **加重下游服务的负载**。

Failover 策略的逻辑如下：

1. **校验**：校验从 AbstractClusterInvoker 传入的 **Invoker 列表是否为空**。

2. **获取配置参数**：从调用的 URL 中获取对应的 `retries` **重试次数**。

3. **初始化一些集合和对象**：用于 **保存调用过程中出现的异常**、**记录调用了哪些节点**（这个会在负载均衡中使用，在某些配置下，尽量不要一直调用同一个服务）。

4. **使用 for 循环实现重试**：for 循环的次数就是重试的次数，成功则返回，否则继续循环，如果 for 循环完，还没有一个成功的返回，则抛出异常，把第 3 步中记录的信息抛出去。

   > for 循环中的具体逻辑如下：
   >
   > - **校验**：如果 for 循环次数大于 1，即有过一次失败，则会再次 **校验节点是否被销毁**、**传入的 Invoker 列表是否为空**。
   > - **负载均衡**：调用 select 方法做负载均衡，得到 **要调用的节点**，并 **记录这个节点到步骤 3 的集合里**，再把已经调用的节点信息 **放进 RPC 上下文中**。
   > - **远程调用**：调用 `invoker#invoke` 方法做远程调用，成功则返回，异常则记录异常信息，再做下次循环。

##### Failfast 策略

> - **快速失败**，当请求失败后，快速返回异常结果，不做任何重试。
> - 该容错机制 **会对请求做负载均衡**，通常使用在 **非幂等接口** 的调用上。
> - 该机制 **受网络抖动的影响较大**。

Failfast 会在失败后直接抛出异常并返回，实现非常简单，步骤如下：

1. **校验**：校验从 AbstractClusterInvoker **传入的 Invoker 列表是否为空**。
2. **负载均衡**：调用 `select` 方法做负载均衡，**得到要调用的节点**。
3. **远程调用**：在 `try` 代码块中调用 `invoker#invoke` 方法做远程调用，如果捕获到异常，则直接封装成 RpcEception 抛出。

> :information_desk_person: 整个过程非常简短，也不会做任何中间信息的记录。

##### Failsafe 策略

> - 当出现异常时，直接 **忽略异常**。
>
> - 会 **对请求做负载均衡**，通常使用在 『佛系』调用场景，即 **不关心调用是否成功**，并且 **不想抛异常影响外层调用**，如某些 **不重要的日志同步**，即使出现异常也无所谓。

Failsafe 调用时如果出现异常，则会直接忽略，实现也非常简单，步骤如下：

1. **校验**：校验从 AbstractClusterInvoker **传入的 Invoker 列表是否为空**。
2. **负载均衡**：调用 `select` 方法做负载均衡，**得到要调用的节点**。
3. **远程调用**：在 `try` 代码块中调用 `invoker#invoke` 方法做远程调用，`catch` 到任何异常都直接『吞掉』，返回一个 **空的结果集**。

##### Failback 策略

> - 请求失败后，会自动 **记录在失败队列中**，并 **由一个定时线程池定时重试**。
> - 该机制适用于一些 **异步** 或 **最终一致性** 的请求，请求 **会做负载均衡**。

Failback 如果调用失败，则会 **定期重试**，FailbackClusterInvoker 里面定义了一个 ConcurrentHashMap，专门用来 **保存失败的调用**，另外定义了一个 **定时线程池**，默认 **每 5 秒把所有失败的调用拿出来**，**重试一次**，如果调用 **重试成功**，则会 **从 ConcurrentHashMap 中移除**，调用逻辑如下：

1. **校验**：校验从 AbstractClusterInvoker **传入的 Invoker 列表是否为空**。
2. **负载均衡**：调用 `select` 方法做负载均衡，**得到要调用的节点**。
3. **远程调用**：在 `try` 代码块中调用 `invoker#invoke` 方法做远程调用，`catch` 到异常后直接把 `invocation` **保存到重试的 ConcurrentHashMap 中**，并 **返回一个空的结果集**。
4. **重新请求**：定时线程池会定时把 ConcurrentHashMap 中的失败请求拿出来重新请求，请求成功则从 ConcurrentHashMap 中移除，如果请求还是失败，则异常也会被 `catch` 住，不会影响 ConcurrentHashMap 中后面的重试。

##### Forking 策略

> - 同时调用多个 **相同** 的服务，只要其中 **一个返回**，则 **立即返回结果**。
> - 用户可以配置 forks = "最大并行调用数" 参数来确定并行调用的服务数量。
> - 通常使用在对接口 **实时性要求极高** 的调用上，但也会浪费更多的资源。

Forking 可以同时并行请求多个服务，有任何一个返回，则直接返回，步骤如下：

1. **准备工作**：检验传入的 Invoker 列表是否可用；初始化一个 Invoker 集合，用于保存真正要调用的 Invoker 列表；从 URL 中得到最大并行数、超时时间。

2. **获取最终要调用的 Invoker 列表**：假设用户设置最大的并行数为 $n$，实际可以调用的最大服务数为 $v$，如果 $n < 0$ 或 $n > v$，则说明可用的服务数小于用户的设置，因此最终要调用的 Invoker 只能有 $v$ 个；如果 $n < v$，则会循环调用负载均衡方法，不断得到可调用的 Invoker，加入步骤 1 中的 Invoker 集合里。

   > :information_desk_person: 在 Invoker 加入集合时，会做 **去重** 操作，因此，如果用户设置的负载均衡策略每次返回的都是同一个 Invoker，那么集合中最后只会存在一个 Invoker，也就是只会调用一个节点。

3. **调用前的准备工作**：设置要调用的 Invoker 列表到 RPC 上下文；初始化一个异常计数器；初始化一个阻塞队列，用于记录并行调用的结果。

4. **执行调用**：循环使用线程池并行调用，**调用成功**，则 **把结果加入阻塞队列**；**调用失败**，则 **失败计数 +1**。如果 **所有线程的调用都失败了**，即 **失败计数 ≥ 所有可调用的 Invoker** 时，才会 **把异常信息放入阻塞队列**，所以 **只有当最后一个 Invoker 也调用失败时**，**才会把异常信息放入阻塞队列**，从而达到 **全部失败才返回异常的结果**。

5. **同步等待结果**：由于步骤 4 中的步骤是在 [线程池](https://notebook.ricear.com/project-34/doc-818) 中执行的，因此主线程还会继续往下执行，主线程中会使用阻塞队列的 `poll(timeout)` 方法，**同步等待** 阻塞队列中的第一个结果，如果是 **正常结果则返回**，如果是 **异常则抛出**。

从以上步骤可以得知，Forking 的超时是通过在阻塞队列的 `poll` 方法中传入超时时间实现的；线程池中的并发调用会 **获取第一个正常返回结果**。只有 **所有请求都失败了**，**Forking 才会失败**。Forking 调用流程如下图所示：

![image-20220810145615738](https://notebook.ricear.com/media/202208/2022-08-10_145629_2016600.2488753752048849.png)

#### 负载均衡

##### 包装后的负载均衡

封装后的负载均衡具有了一些新的特性：

1. **粘滞连接**：粘滞连接用于 **有状态服务**，尽可能让客户端总是 **向同一提供者发起调用**，除非该提供者挂了，再连接另一台。粘滞连接将自动开启 **延迟连接**，以减少长连接数。
2. **可用检测**：框架调用的 URL 中，如果含有 `cluster.avaliablecheck=false`，则不会检测远程服务是否可用，直接调用；如果不设置，则默认会开启检查，对所有的服务都做是否可用的检查，如果不可用，则再次做负载均衡。
3. **避免重复调用**：对于已经调用过的远程服务，避免重复选择，每次都使用同一个节点。这种特性主要是为了 **避免并发场景下**，**某个节点瞬间被大量请求**。

整个逻辑过程大致可以分为如下 4 步：

1. **检查 URL 中是否有配置粘滞连接**，如果 **有**，则 **使用粘滞连接的 Invoker**；如果 **没有配置粘滞连接**，或者 **重复调用检测不通过**，则 **进入第 2 步**。

2. 通过 ExtensionLoader 获取负载均衡的具体实现，并 **通过负载均衡做节点的选择**，对选择出来的节点做重复调用、可用性检测，通过则直接返回，否则进入第 3 步。

3. **进行节点的重新选择**，如果需要做可用性检测，则会遍历 Directory 中得到的所有节点，过滤不可用和已经调用过的节点，在剩余的节点中重新做负载均衡；如果不需要做可用性检测，那么也会遍历 Directory 中得到的所有节点，但只过滤已经调用过的，在剩余的节点中重新做负载均衡。

   > :information_desk_person: 如果在过滤不可用或已经调用过的节点时，节点全部被过滤，没有剩下任何节点，则 **遍历所有已经调用过的节点**，**选出所有可用的节点**，再 **通过负载均衡选出一个节点并返回**，如果还找不到可调用的节点，则返回 `null`。

> :information_desk_person: 从上述逻辑中，我们可以得知，框架会 **优先处理粘滞连接**；否则会 **根据可用性检测或重复调用检测过滤一些节点**，并 **在剩余的节点中做负载均衡**；如果 **可用性检测或重复调用检测把节点都过滤了**，则兜底的策略是 **在已经调用过的节点中通过负载均衡选择出一个可用的节点**。

##### 分类

框架现在支持两种负载均衡策略，分别为 [RoundRobin 负载均衡](https://notebook.ricear.com/project-46/doc-828/#4-1-%E8%BD%AE%E8%AF%A2%E6%B3%95) 和 [一致性哈希负载均衡](https://notebook.ricear.com/project-37/doc-762)。

## 项目难点

### 客户端和服务端连接经常断掉

1. 以前使用的时候可能会出现客户端一段时间没有发送数据后会导致客户端与服务端断开连接，这样如果再使用的时候就需要重新连接，比较浪费时间。
2. 后面我们增加了 Netty 心跳机制，如果 15 秒内还没有数据发送，就会发送一个心跳到服务器，具体实现为：
   1. 在`NettyRpcClient` 中添加了一个`IdleStateHandler`，然后自定义了一个`NettyRpcClientHandler` 继承自`ChannelInboundHandlerAdapter` 并实现了`userEventTriggered()` 方法，在该方法中会判断当前的事件类型，如果为`IdleState.WRITER_IDLE`，即一段时间没有数据发送，则会发送一个心跳给服务器，保持客户端和服务器的连接。

### 一个接口有多个类实现如何区分服务

1. 原来我们的服务名称是直接使用接口名来做的（因为类名有可能发生变化，而接口名一般是不变的，所以没有使用类名），这样当一个类有多个实现的时候，会导致服务无法区分。
2. 后来我们引入了服务组名，将服务名称改为了`接口名 + 组名 + 版本号` 的方式，这样就可以了。

## 其他问题

### 什么是远程过程调用

详见 [RPC](https://notebook.ricear.com/project-46/doc-836)。

### Zookeeper 怎么知道是健康的节点

参考 [服务探活](https://mp.weixin.qq.com/s?__biz=MzI5NjE2MDQwNg==&mid=2247486141&idx=1&sn=074744ce828516f98d3fa0ea725693ac&scene=21#wechat_redirect)。

> :thinking: 健康的节点如果挂掉了怎么办?

> :thinking: 挂掉的节点又好了怎么处理？

### 使用了哪些设计模式

1. **[单例模式](https://notebook.ricear.com/project-42/doc-767)**

   1. 采用[饿汉式](https://notebook.ricear.com/project-42/doc-767/#4-1-%E9%A5%BF%E6%B1%89%E5%BC%8F)的方式。
   2. 比如`NettyRpcClient`、`NettyRpcServer` 等都采用单例模式获取单例。
2. **[工厂模式](https://notebook.ricear.com/project-42/doc-769)**

   1. 采用[反射模式](https://notebook.ricear.com/project-34/doc-820)实现工厂模式。
3. **[代理模式](https://notebook.ricear.com/project-42/doc-770/#3-2-%E5%8A%A8%E6%80%81%E4%BB%A3%E7%90%86)**

   1. 通过[动态代理](https://notebook.ricear.com/project-42/doc-770/#3-2-%E5%8A%A8%E6%80%81%E4%BB%A3%E7%90%86)来屏蔽复杂的网络传输细节，当我们去调用一个远程的方法时，实际上是通过代理对象调用的，网络传输细节都封装在了`RpcClientProxy.invoke()` 中。

## 参考文献

1. 《深入理解Apache Dubbo与实战》
2. [Dubbo - 为什么要选择使用zookeeper做为注册中心?](https://www.pianshen.com/article/1246155689)