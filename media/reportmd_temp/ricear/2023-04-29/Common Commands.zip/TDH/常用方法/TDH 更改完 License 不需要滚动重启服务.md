---
sidebar_position: 2
---

TDH 更改完 License 不需要滚动重启服务

