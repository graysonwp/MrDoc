---
sidebar_position: 1
---

```shell
beeline -u jdbc:hive2://192.168.2.205:10000/default
```


