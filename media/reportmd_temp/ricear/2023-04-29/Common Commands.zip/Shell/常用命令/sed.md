---
sidebar_position: 6
---

- 删除文件第一行  
  ```shell
  # 删除文件第一行，sed -i 表示将改动直接写入到原文件里
  sed -i '1d'  txtfilename
  ```
