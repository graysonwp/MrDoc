---
sidebar_position: 5
---

- 快速移动光标：
  - 行首：`shift+6`
  - 行尾：`shift+4`


