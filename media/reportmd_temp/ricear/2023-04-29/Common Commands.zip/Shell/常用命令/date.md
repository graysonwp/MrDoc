---
sidebar_position: 7
---

```shell
date +"%Y-%m-%d %H:%M:%S"
date -d "+1second" +"%Y-%m-%d %H:%M:%S"
date -d "+1minute" +"%Y-%m-%d %H:%M:%S"
date -d "+1hour" +"%Y-%m-%d %H:%M:%S"
date -d "+1day" +"%Y-%m-%d %H:%M:%S"
date -d "+1month" +"%Y-%m-%d %H:%M:%S"
date -d "+2year" +"%Y-%m-%d %H:%M:%S"
date -d"+1day 2015-04-01" +%Y-%m-%d
```


