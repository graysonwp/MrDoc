---
sidebar_position: 5
---

```shell

#!bin/bash
# 将 mongodb 中的数据拉取到本地，然后导入到 hive 中
# 日期格式
DATE_FORMAT="+%Y%m%d"
# 起始日期
if [ ! ${1} ]; then
	START_DAY=`date -d "-1day" ${DATE_FORMAT}`
else
	START_DAY=`date -d "-1day ${1}" ${DATE_FORMAT}`
fi
# 截止日期
if [ ! ${2} ]; then
	END_DAY=${START_DAY}
else
	END_DAY=`date -d "-1day ${2}" ${DATE_FORMAT}`
fi
echo ${START_DAY}
echo ${END_DAY}
# python 脚本路径
PYTHON_SCRIPT_PATH="/usr/local/projects/PocketFilm/Spider/PocketLifeSpider/PocketLifeSpider"
EXPORT_PATH="/usr/local/projects/PocketFilm/files/documentations/mongodb/export"
HDFS_DOMAIN_PATH="/user/hive/warehouse/pocket.db"

START_DAY_TMP=${START_DAY}
END_DAY_TMP=${END_DAY}
while (( "${START_DAY_TMP}" <= "${END_DAY_TMP}" )); do
 cur_day=`date -d ${START_DAY_TMP} ${DATE_FORMAT}`
 echo "Current date is ${cur_day}:"
 echo "Run mongo-to-local.py"
 /usr/local/python3/bin/python3 ${PYTHON_SCRIPT_PATH}/mongo-to-local.py ${cur_day}
 echo "Add partition for hive"
 beeline -u jdbc:hive2://192.168.2.205:10000/pocket -e "alter table movie add if not exists partition(date_id=${cur_day})"
 beeline -u jdbc:hive2://192.168.2.205:10000/pocket -e "alter table tv add if not exists partition(date_id=${cur_day})"
 beeline -u jdbc:hive2://192.168.2.205:10000/pocket -e "alter table drama add if not exists partition(date_id=${cur_day})"
 beeline -u jdbc:hive2://192.168.2.205:10000/pocket -e "alter table piece add if not exists partition(date_id=${cur_day})"
 echo "Upload file to hdfs"
 hdfs dfs -put ${EXPORT_PATH}/${cur_day}/movie.csv ${HDFS_DOMAIN_PATH}/movie/date_id=${cur_day}
 hdfs dfs -put ${EXPORT_PATH}/${cur_day}/tv.csv ${HDFS_DOMAIN_PATH}/tv/date_id=${cur_day}
 hdfs dfs -put ${EXPORT_PATH}/${cur_day}/drama.csv ${HDFS_DOMAIN_PATH}/drama/date_id=${cur_day}
 hdfs dfs -put ${EXPORT_PATH}/${cur_day}/piece.csv ${HDFS_DOMAIN_PATH}/piece/date_id=${cur_day}
 START_DAY_TMP=`date -d "+1day ${START_DAY_TMP}" ${DATE_FORMAT}`
done
```

