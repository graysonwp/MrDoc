---
sidebar_position: 1
---

Manager 中修改完参数后需要先配置服务，然后再点击重启(会重新拉取镜像)，不要直接点击启动。

