---
sidebar_position: 2
---

```shell

iptables -t nat -A DOCKER -p tcp --dport 3306 -j DNAT --to 172.17.0.4:3306
iptables -t nat -A POSTROUTING -p tcp -s 172.17.0.4 -d 172.17.0.4 --dport 3306 -j MASQUERADE
iptables -A DOCKER -p tcp --dport 3306 -d 172.17.0.4 -j ACCEPT
```

