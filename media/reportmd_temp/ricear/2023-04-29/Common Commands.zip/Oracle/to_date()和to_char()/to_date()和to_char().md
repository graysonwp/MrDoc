---
sidebar_position: 1
---

- 转换的格式：  
  表示 year 的：y 表示年的最后一位 yy 表示年的最后 2 位 yyy 表示年的最后 3 位 yyyy 用 4 位数表示年
  
  表示 month 的：mm 用 2 位数字表示月；mon 用简写形式 比如 11 月或者 nov ；month 用全称 比如 11 月或者 november
  
  表示 day 的：dd 表示当月第几天；ddd 表示当年第几天；dy 当周第几天 简写 比如星期五或者 fri；day 当周第几天 全写
  
  比如星期五或者 friday。
  
  表示 hour 的：hh 2 位数表示小时 12 进制； hh24 2 位数表示小时 24 小时
  
  表示 minute 的：mi 2 位数表示分钟
  
  表示 second 的：ss 2 位数表示秒 60 进制
  
  表示季度的：q 一位数 表示季度 （1-4）
  
  另外还有 ww 用来表示当年第几周 w 用来表示当月第几周。
  
  24 小时制下的时间范围：00：00：00-23：59：59
  
  12 小时制下的时间范围：1：00：00-12：59：59
- 示例：

```sql
select to_char(sysdate,'yyyy-mm-dd hh24:mi:ss') from dual  //显示：2008-11-07 13:22:42
select to_date('2005-12-25,13:25:59','yyyy-mm-dd,hh24:mi:ss') from dual //显示：2005-12-25 13:25:59
```

